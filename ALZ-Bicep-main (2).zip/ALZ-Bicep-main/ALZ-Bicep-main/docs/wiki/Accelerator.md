<!-- markdownlint-disable -->
## Accelerator
<!-- markdownlint-restore -->

> [!IMPORTANT]
> The ALZ Bicep Accelerator has been enhanced to streamline the setup of your Version Control System and Azure resources. Comprehensive documentation for the updated ALZ Bicep Accelerator, which continues to utilize the modules in this repository, is now available at [aka.ms/alz/accelerator/docs](https://aka.ms/alz/accelerator/). Visit this link to access the latest guidance and get started quickly!
>
